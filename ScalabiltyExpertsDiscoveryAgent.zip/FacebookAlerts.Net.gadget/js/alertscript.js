

//==================================================================================
//  Declear variables 
//==================================================================================
var feedTimer = null;
var facebookUtil = null;

//==================================================================================
//  GadgetInit 
//==================================================================================
function GadgetInit() 
{
    System.Gadget.settingsUI = "gadgetsettings.htm";
    System.Gadget.onSettingsClosed = SettingsClosed;
}

//==================================================================================
//  SettingsLoading
//==================================================================================
function SettingsLoading()
{
    System.Gadget.onSettingsClosing = SettingsClosing;
    document.getElementById("txtSqlServer").value = System.Gadget.Settings.read("SqlServerName");
    if (System.Gadget.Settings.read("timeIntervalIndex") + "" == "") System.Gadget.Settings.write("timeIntervalIndex", -1);
    document.getElementById("timeInterval").value = System.Gadget.Settings.read("timeIntervalIndex");
}

//==================================================================================
//  SettingsClosing
//==================================================================================
function SettingsClosing(args)
{
    if (args.closeAction == args.Action.commit)
    {
        System.Gadget.Settings.write("SqlServerName", document.getElementById("txtSqlServer").value);
        System.Gadget.Settings.write("timeIntervalIndex", document.getElementById("timeInterval").value);
    }
}

//==================================================================================
//  SettingsClosed
//==================================================================================
function SettingsClosed(event)
{
    if (event.closeAction == event.Action.commit) 
    {
        // If there is no sqlservername.
        if (System.Gadget.Settings.read("SqlServerName") + "" == "") 
        {
            showErrorPage("Please input a SQL Server name!"); 
            return;
        }
        
        try
        {
            clearInterval(feedTimer);
            feedTimer = null;
        
            // Create the ActiveX Object. 
            facebookUtil = new ActiveXObject("FacebookUtilities.FacebookUtil");

            RefreshDisplay();
            showNotificationsPage();
            feedTimer = setInterval(RefreshDisplay, getTimeInterval());   
        }
        catch (e) 
        { 
            showErrorPage(e.message);
        }
    }
}

//==================================================================================
//  getSettingsFromConfig
//==================================================================================
function getAlertByName(xml, name)
{
    var xmldoc = new ActiveXObject("Microsoft.XMLDOM");
    xmldoc.loadXML(xml);
    return xmldoc.childNodes(0).childNodes(0).getAttribute(name);
}

//==================================================================================
//  showWelcomePage
//==================================================================================
function showWelcomePage()
{
    document.getElementById("initpage").style.display = "block";
    document.getElementById("resultspage").style.display = "none";
    document.getElementById("errorpage").style.display = "none";
}

//==================================================================================
//  showNotificationsPage
//==================================================================================
function showNotificationsPage()
{
    document.getElementById("initpage").style.display = "none";
    document.getElementById("resultspage").style.display = "block";
    document.getElementById("errorpage").style.display = "none";
}

//==================================================================================
//  showErrorPage
//==================================================================================
function showErrorPage(error)
{
    document.getElementById("initpage").style.display = "none";
    document.getElementById("resultspage").style.display = "none";
    document.getElementById("errorpage").style.display = "block";
    document.getElementById("noteError").innerText = error;   
}

//==================================================================================
//  Get time interval for refresh.
//==================================================================================
function getTimeInterval()
{
    var index = System.Gadget.Settings.read("timeIntervalIndex"); 
    if (index == -1) return 15000;      // 15 seconds
    if (index == 0) return 30000;       // 30 seconds
    if (index == 1) return 60000;       // 1 minute
    if (index == 2) return 300000;      // 5 minutes
    return 3600000;                     // 1 hour
}

//==================================================================================
//  Refreshes with info the gadget's main window
//==================================================================================
function RefreshDisplay()
{
    try
    {
        // Get the facebook nitifacations.
        var xmlAlerts = facebookUtil.GetAlerts(System.Gadget.Settings.read("SqlServerName"));
        
        // Display the current user's name.
        document.getElementById("facebookusername").innerText = getAlertByName(xmlAlerts, "Name");
  
        // Display of the records counts.
        var msgCount = getAlertByName(xmlAlerts, "msgCount");
        var pokeCount = getAlertByName(xmlAlerts, "pokeCount");
        var shareCount = getAlertByName(xmlAlerts, "shareCount");
        var friendinvitationCount = getAlertByName(xmlAlerts, "friendinvitationCount");
        var groupinvitationCount = getAlertByName(xmlAlerts, "groupinvitationCount"); 
        var eventinvitationCount = getAlertByName(xmlAlerts, "eventinvitationCount");
        document.getElementById("messageCount").innerText = msgCount;
        document.getElementById("pokeCount").innerText = pokeCount;
        document.getElementById("shareCount").innerText = shareCount;
        document.getElementById("friendInvitesCount").innerText = friendinvitationCount;
        document.getElementById("groupInvitesCount").innerText = groupinvitationCount; 
        document.getElementById("eventInvitesCount").innerText = eventinvitationCount;
        
        // Display of the received time.
        var Now = new Date();
        var Then;  
        var mostrecentmsgtime = getAlertByName(xmlAlerts, "mostrecentmsgtime");
        var mostrecentpoketime = getAlertByName(xmlAlerts, "mostrecentpoketime");
        var mostrecentsharetime = getAlertByName(xmlAlerts, "mostrecentsharetime");
        var friendrequeststime = getAlertByName(xmlAlerts, "friendrequeststime");
        var groupinvitestime = getAlertByName(xmlAlerts, "groupinvitestime");
        var eventinvitestime = getAlertByName(xmlAlerts, "eventinvitestime");
        
        // Messages
        if (mostrecentmsgtime == "" || msgCount == 0)
            document.getElementById("messageTime").innerText = "";
        else
        {
            Then = new Date(mostrecentmsgtime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("messageTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else
                document.getElementById("messageTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
        
        // Pokes
        if (mostrecentpoketime == "" || pokeCount == 0)
            document.getElementById("pokeTime").innerText = "";
        else
        {
            Then = new Date(mostrecentpoketime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("pokeTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else 
                document.getElementById("pokeTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
        
        // Shares
        if (mostrecentsharetime == "" || shareCount == 0)
            document.getElementById("shareTime").innerText = "";
        else
        {
            Then = new Date(mostrecentsharetime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("shareTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else 
                document.getElementById("shareTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
    	    
        // Friends Requests
        if (friendrequeststime == "" || friendinvitationCount == 0)
            document.getElementById("friendInvitesTime").innerText = "";
        else
        {
            Then = new Date(friendrequeststime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("friendInvitesTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else 
                document.getElementById("friendInvitesTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
        
        // Group Invitations
        if (String(groupinvitestime) == "" || groupinvitationCount == 0)
            document.getElementById("groupInvitesTime").innerText = "";
        else
        {
            Then = new Date(groupinvitestime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("groupInvitesTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else 
                document.getElementById("groupInvitesTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
        
        // Event Invitations
        if (String(eventinvitestime) == "" || eventinvitationCount == 0)
            document.getElementById("eventInvitesTime").innerText = "";
        else
        {
            Then = new Date(eventinvitestime);
            if (Then.toDateString() == Now.toDateString()) 
                document.getElementById("eventInvitesTime").innerText = "(" + Then.toTimeString().substring(0,8) + ")";
            else 
                document.getElementById("eventInvitesTime").innerText = "(" + (Then.getMonth()+1) + "/" + Then.getDate() + "/" + Then.getFullYear().toString().substring(2,4) + ")";
        }
    }
    catch (e) 
    { 
        clearInterval(feedTimer);
        feedTimer = null;
        showErrorPage(e.message);
    }
}