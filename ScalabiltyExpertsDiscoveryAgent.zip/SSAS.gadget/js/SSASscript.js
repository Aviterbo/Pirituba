

//==================================================================================
//  Declear variables 
//==================================================================================
var feedTimer = null;
var panelID = "p1"
var numOfTabs = 3
var dbnames = null;
var cubenames = null;
var kpinames = null;
var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
var ssasUtil = new ActiveXObject("SSASUtilities.SSASUtil");
      
//==================================================================================
//  GadgetInit 
//==================================================================================
function GadgetInit() 
{
    System.Gadget.settingsUI = "gadgetsettings.htm";
    System.Gadget.onSettingsClosed = SettingsClosed;
}

//==================================================================================
//  SettingsLoading
//==================================================================================
function SettingsLoading()
{
    System.Gadget.onSettingsClosing = SettingsClosing;
    document.getElementById("txtSqlServer").value = System.Gadget.Settings.read("SqlServer");
    
    dbnames = document.getElementById('dbNames');
    cubenames = document.getElementById('cubeNames');
    kpinames = document.getElementById('kpiNames');
    
    selecteddbname = System.Gadget.Settings.read("SqlDatabase");
    selectedcubename = System.Gadget.Settings.read("SqlCube");
    selectedkpinames = System.Gadget.Settings.read("SqlKPIs");
    selecteddbindex = System.Gadget.Settings.read("DBIndex");
    selectedcubeindex = System.Gadget.Settings.read("CubeIndex");
    selectedkpiindices = System.Gadget.Settings.read("KPIIndices");
    
    dbnames.options.length = 0;
    if (selecteddbindex > -1) 
    {
        // ****DB section
        // Get server name.
        var serverName = document.getElementById("txtSqlServer").value;
        // Get DBs.
        xmlDoc.loadXML(ssasUtil.GetDatabases(serverName));
        var dbs = xmlDoc.getElementsByTagName('Database');
        // Populate the DBs combobox.
        dbnames.options.length = 0;
        dbnames.options.length = dbs.length;
        for (i=0; i<dbnames.length; i++)
        {
            dbnames.options[i].text = dbnames.options[i].value = dbs[i].getAttribute('Name');
        }
        // Restore the settings
        dbnames.options.selectedIndex = selecteddbindex;
        
        // ****Cube section
        cubenames.options.length = 0;
        if (selectedcubeindex > -1)
        {
            // Get values.
            var serverName = document.getElementById("txtSqlServer").value;
            var dbName = dbnames.options[dbnames.options.selectedIndex].value;
            // Get Cubes.
            xmlDoc.loadXML(ssasUtil.GetCubes(serverName, dbName));
            var cubes = xmlDoc.getElementsByTagName('Cube');
            // Populate the cubes combobox.
            cubenames.options.length = 0;
            cubenames.options.length = cubes.length;
            for (i=0; i<cubes.length; i++)
            {
                cubenames.options[i].text = cubenames.options[i].value = cubes[i].getAttribute('Name');
            }
            // Restore the settings
            cubenames.options.selectedIndex = selectedcubeindex;
        }
        
        // ****KPI section
        kpinames.options.length = 0;
        var selectedkpiindices = System.Gadget.Settings.read("SqlKPIIndices").split(" ,");
        if (selectedkpiindices.length > 0)
        {
            // Get values.
            var serverName = document.getElementById("txtSqlServer").value;
            var dbName = dbnames.options[dbnames.options.selectedIndex].value;
            var cubeName = cubenames.options[cubenames.options.selectedIndex].value;
            // Get KPIs.
            xmlDoc.loadXML(ssasUtil.GetKPIs(serverName, dbName, cubeName));
            var kpis = xmlDoc.getElementsByTagName('KPI');
            // Populate the KPIs combobox.
            kpinames.options.length = kpis.length;
            for (i=0; i<kpis.length; i++)
            {
                kpinames.options[i].text = kpinames.options[i].value = kpis[i].getAttribute('Name');
            }
            // Restore the settings
            for (i=0; i<selectedkpiindices.length; i++)
            {
                kpinames.options[selectedkpiindices[i]].selected = true;
            }
        }
     }
}

//==================================================================================
//  SettingsClosing
//==================================================================================
function SettingsClosing(args)
{
    if (args.closeAction == args.Action.commit)
    {
        System.Gadget.Settings.write("SqlServer", document.getElementById("txtSqlServer").value);
        System.Gadget.Settings.write("DBIndex", dbnames.options.selectedIndex);
        System.Gadget.Settings.write("CubeIndex", cubenames.options.selectedIndex);
        
        // Selected DB Index
        if (dbnames.options.length > 0)
            System.Gadget.Settings.write("DBIndex", dbnames.options.selectedIndex);
        else
            System.Gadget.Settings.write("DBIndex", -1);
        // Selected Cube Index
        if (cubenames.options.length > 0)
            System.Gadget.Settings.write("CubeIndex", cubenames.options.selectedIndex);
        else
            System.Gadget.Settings.write("CubeIndex", -1);
        
        // Selected DB
        if (dbnames.options.length > 0)
        {
            if (dbnames.options.selectedIndex > -1)
                System.Gadget.Settings.write("SqlDatabase", dbnames.options[dbnames.options.selectedIndex].value);
        }
        else
            System.Gadget.Settings.write("SqlDatabase", "");
        // Selected Cube
        if (cubenames.options.length > 0)
        {
            if (cubenames.options.selectedIndex > -1)
                System.Gadget.Settings.write("SqlCube", cubenames.options[cubenames.options.selectedIndex].value);
        }
        else
            System.Gadget.Settings.write("SqlCube", "");
        
        // Selected KPI names and indices
        var SqlKPIs = new Array();
        var SqlKPIIndices = new Array();
        var index = 0;
        for (var i=0; i<kpinames.options.length; ++i)
        {
            if (kpinames.options[i].selected) 
            {
                SqlKPIs[index] = kpinames.options[i].value;
                SqlKPIIndices[index] = i + " ";
                index++;
            }
            // Append dummy component.
            SqlKPIIndices[index] = -1 + " ";
        }
        System.Gadget.Settings.write("SqlKPIs", SqlKPIs);
        System.Gadget.Settings.write("SqlKPIIndices", SqlKPIIndices);
    }
}

//==================================================================================
//  SettingsClosed
//==================================================================================
function SettingsClosed(event)
{
    if (event.closeAction == event.Action.commit) 
    {
        // If there is no sqlservername, then show the error.
        if (System.Gadget.Settings.read("SqlServer") + "" == "") 
        {
            showErrorPage("Please input a SQL Server name!"); 
            return;
        }
        // If there is no sqlservername, then show the error.
        if (System.Gadget.Settings.read("SqlDatabase") + "" == "") 
        {
            showErrorPage("Please select a database!"); 
            return;
        }
        // If there is no sqlservername, then show the error.
        if (System.Gadget.Settings.read("SqlCube") + "" == "") 
        {
            showErrorPage("Please select a cube!"); 
            return;
        }
        
        try
        {
            // Display the first KPI
            var SqlKPIs = System.Gadget.Settings.read("SqlKPIs").split(",");
            if (SqlKPIs.length > 0) GetFirstKPI();
            showResultsPage(); 
        }
        catch (e) 
        { 
            showErrorPage(e.message);
        }
    }
}

function GetFirstKPI()
{
    var SqlKPIs = System.Gadget.Settings.read("SqlKPIs").split(",");
    if (SqlKPIs.length > 0)  GetOneKPI(0);
}

function GetLastKPI()
{
    var SqlKPIs = System.Gadget.Settings.read("SqlKPIs").split(",");
    if (SqlKPIs.length > 0) GetOneKPI(SqlKPIs.length-1);
}

function GetPreviousKPI()
{
    var indexKPI = parseInt(document.getElementById("indexKPI").innerText, 10);
    if (indexKPI > 1)  GetOneKPI(indexKPI-2);
}

function GetNextKPI()
{
    var indexKPI = parseInt(document.getElementById("indexKPI").innerText, 10);
    var SqlKPIs = System.Gadget.Settings.read("SqlKPIs").split(",");
    if (SqlKPIs.length > indexKPI)  GetOneKPI(indexKPI);
}

function GetOneKPI(indexKPI)
{
    try
    {
        // Initialize the labels.
        document.getElementById("SqlKPIName").innerText = "";
        document.getElementById("indexKPI").innerText = "";
        document.getElementById("SqlKPIValue").innerText = "";
        document.getElementById("SqlKPIGoal").innerText = "";
        document.getElementById("SqlKPIStatus").innerText = "";
        document.getElementById("SqlKPITrend").innerText = "";
        document.getElementById("SqlKPIStatusGraphic").innerText = "";
        document.getElementById("SqlKPITrendGraphic").innerText = "";
                
        var server = System.Gadget.Settings.read("SqlServer");
        var database = System.Gadget.Settings.read("SqlDatabase");
        var cube = System.Gadget.Settings.read("SqlCube");
        var SqlKPIs = System.Gadget.Settings.read("SqlKPIs").split(",");
        var kpi = SqlKPIs[indexKPI];
        document.getElementById("SqlKPIName").innerText = kpi;
        document.getElementById("indexKPI").innerText = (indexKPI+1);
        
        xmlDoc.loadXML(ssasUtil.GetKPIs(server, database, cube));
        var kpis = xmlDoc.getElementsByTagName('KPI');
        
        for (i=0; i<kpis.length; i++)
        {
            if (kpis[i].getAttribute('Name') == kpi)
            {
                document.getElementById("SqlKPIValue").innerText = kpis[i].getAttribute('Value');
                document.getElementById("SqlKPIGoal").innerText = kpis[i].getAttribute('Goal');
                document.getElementById("SqlKPIStatus").innerText = kpis[i].getAttribute('Status');
                document.getElementById("SqlKPITrend").innerText = kpis[i].getAttribute('Trend');
                document.getElementById("SqlKPIStatusGraphic").innerText = kpis[i].getAttribute('StatusGraphic').replace(/ - /, ":");
                document.getElementById("SqlKPITrendGraphic").innerText = kpis[i].getAttribute('TrendGraphic').replace(/ - /, ":");
            }
        }
        
        showResultsPage(); 
    }
    catch (e) 
    { 
        showErrorPage(e.message);
    }
}

function GetDatabases()
{
    // Get server name.
    var serverName = document.getElementById("txtSqlServer").value;
    
    // Get DBs.
    xmlDoc.loadXML(ssasUtil.GetDatabases(serverName));
    var dbs = xmlDoc.getElementsByTagName('Database');
    
    // Populate the DBs combobox.
    dbnames.options.length = 0;
    dbnames.options.length = dbs.length;
    for (i=0; i<dbnames.length; i++)
    {
        dbnames.options[i].text = dbnames.options[i].value = dbs[i].getAttribute('Name');
    }
    
    // Populate the cubes combobox.
    if (dbnames.options.selectedIndex > -1) GetCubes();
    else
    {
        var cubenames = document.getElementById('cubeNames');
        cubenames.options.length = 0;
        var kpinames = document.getElementById('kpiNames');
        kpinames.options.length = 0;
    }
}

function GetCubes() 
{
    // Get values.
    var serverName = document.getElementById("txtSqlServer").value;
    var dbName = dbnames.options[dbnames.options.selectedIndex].value;
    
    // Get Cubes.
    xmlDoc.loadXML(ssasUtil.GetCubes(serverName, dbName));
    var cubes = xmlDoc.getElementsByTagName('Cube');
    
    // Populate the cubes combobox.
    cubenames.options.length = 0;
    cubenames.options.length = cubes.length;
    for (i=0; i<cubes.length; i++)
    {
        cubenames.options[i].text = cubenames.options[i].value = cubes[i].getAttribute('Name');
    }
    
    // Populate the KPIs combobox.
    if (cubenames.options.selectedIndex > -1) GetKPIs();
    else
    {
        var kpinames = document.getElementById('kpiNames');
        kpinames.options.length = 0;
    }
}
        
function GetKPIs() 
{
    // Initialize.
    kpinames.options.length = 0;
    
    // Get values.
    var serverName = document.getElementById("txtSqlServer").value;
    var dbName = dbnames.options[dbnames.options.selectedIndex].value;
    var cubeName = cubenames.options[cubenames.options.selectedIndex].value;
    
    // Get KPIs.
    xmlDoc.loadXML(ssasUtil.GetKPIs(serverName, dbName, cubeName));
    var kpis = xmlDoc.getElementsByTagName('KPI');
    
    // Populate the KPIs combobox.
    kpinames.options.length = kpis.length;
    for (i=0; i<kpis.length; i++)
    {
        kpinames.options[i].text = kpinames.options[i].value = kpis[i].getAttribute('Name');
    }

    // Select the first item.
    if (kpis.length > 0) kpinames.options.selectedIndex = 0;
}

//==================================================================================
//  getDiv
//==================================================================================
function getDiv(s, i) 
{
    var div;
    if (navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.charAt(0) < 5)
        div = document.all.item(panelID + s + i);
    else 
        div = document.getElementById(panelID + s + i);
    return div;
}
 
//==================================================================================
//  selectTab
//==================================================================================
function selectTab(n) 
{
    // Set tab positions & zIndex. Update location
    for (var i=0; i<3; ++i) 
    {
        div = getDiv("panel", i);
        if (i == n) div.style.zIndex = numOfTabs;
        else div.style.zIndex = numOfTabs - i;
    }
}

//==================================================================================
//  showWelcomePage
//==================================================================================
function showWelcomePage()
{
    document.getElementById("initpage").style.display = "block";
    document.getElementById("resultspage").style.display = "none";
    document.getElementById("errorpage").style.display = "none";
}

//==================================================================================
//  showNotificationsPage
//==================================================================================
function showResultsPage()
{
    document.getElementById("initpage").style.display = "none";
    document.getElementById("resultspage").style.display = "block";
    document.getElementById("errorpage").style.display = "none";
}

//==================================================================================
//  showErrorPage
//==================================================================================
function showErrorPage(error)
{
    document.getElementById("initpage").style.display = "none";
    document.getElementById("resultspage").style.display = "none";
    document.getElementById("errorpage").style.display = "block";
    document.getElementById("noteError").innerText = error;   
}